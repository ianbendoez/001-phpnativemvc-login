# phpnativemvc-login
Source Code PHP Native MVC (CRUD) - Login

001 PHP Native MVC - Login.rar

Username: admin / member

Password: dds

Fitur:
- PHP Native
- MVC method
- OOP method
- Fast Loading method
- CRUD tanpa RELOAD browser/halaman
- Dinamis menu untuk setiap user login
- Multi hak akses user
- Multi kode akses user
- Kostum menu user
- Role user (Create, Read, Update, Delete)
- Reset password
- Validasi Input Data (Sweetalert) frond-end & back-end
- Informasi Error/Success ajax/sql proses (Toast&sweetalert)
- Tabel Referensi method (untuk mempermudah mapping data & pengelolaan referensi data)
- Force Logout (1 user 1 session aktif)
- User/Menu/Kode/Referensi manage

Source Code (Gratis)
Password SQL database (Gratis) silahkan kunjungi link dibawah ini.

Chanel Youtube : 
https://youtube.com/playlist?list=PLuoBhQTNG8CBgJKNVbkUUzZgKTIVnq_b7

Tutorial dan Petunjuk Teknis Penggunaan!

*Wajib subscribe & like terimakasih.

Screen Shot:

-Form Login
![Form Login](https://user-images.githubusercontent.com/36695013/185781797-9645358d-e1bc-4ec5-a51c-fdf3eae9454d.png)

- Dashboard
![Dashboard](https://user-images.githubusercontent.com/36695013/185781807-7a46a9ce-d45f-4d92-9240-177701faca6e.png)

- Ganti Kode User
![Ganti Kode User](https://user-images.githubusercontent.com/36695013/185781832-5d0e1342-7648-49f0-9d7b-6975ef8ce02f.png)

- Ganti Password
![Ganti Password](https://user-images.githubusercontent.com/36695013/185781846-864d4a0f-ef73-416b-9b4d-d56dda976877.png)

- Manajemen Hak Akses
![Hak Akses Manajemen](https://user-images.githubusercontent.com/36695013/185781862-57f0eabf-9748-4301-9782-ea28bd7f7fac.png)

- Manajemen Kode Akses
![Kode Akses Manajemen](https://user-images.githubusercontent.com/36695013/185781879-e5aee571-21a0-4ca4-b15f-6dd5e5490d78.png)

- Manajemen Kode
![Kode Manajemen](https://user-images.githubusercontent.com/36695013/185781890-d144b2e2-dc24-4a98-8e63-be03a967cd6a.png)

- Manajemen Menu
![Menu Manajemen](https://user-images.githubusercontent.com/36695013/185781900-ca3698d5-dd4d-493b-bcc9-b622e9f979ca.png)

- Manajemen User
![User Manajemen](https://user-images.githubusercontent.com/36695013/185781911-87316164-c2b1-432e-8c07-8999771a9e8c.png)

- Manajemen Referensi
![Referensi Manajemen](https://user-images.githubusercontent.com/36695013/185781920-edfadcee-38cd-4666-948d-0caad24fe668.png)
